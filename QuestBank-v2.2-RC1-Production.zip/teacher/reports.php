<?php
require_once __DIR__ . '/../app/bootstrap.php';

AuthService::enforceRole('teacher');
$pdo = getDBConnection();

$teacher_id = $_SESSION['user_id'];

$selected_exam = $_GET['exam_title'] ?? 'all';
$selected_category = $_GET['exam_category'] ?? 'all';
$selected_qual_status = $_GET['qualification_status'] ?? 'all';
$selected_subject = $_GET['subject'] ?? 'all';
$selected_section = $_GET['section'] ?? 'all';
$selected_period = $_GET['academic_period'] ?? 'all';
$selected_semester = $_GET['semester'] ?? 'all';
$selected_sy = $_GET['school_year'] ?? 'all';

$where = "WHERE es.teacher_id = ?";
$params = [$teacher_id];

if ($selected_exam !== 'all') {
    $where .= " AND es.exam_title = ?";
    $params[] = $selected_exam;
}

if ($selected_category !== 'all') {
    $where .= " AND e.exam_category = ?";
    $params[] = $selected_category;
}

if ($selected_qual_status !== 'all') {
    $where .= " AND es.qualification_status = ?";
    $params[] = $selected_qual_status;
}

if ($selected_subject !== 'all') {
    $where .= " AND (e.subject = ? OR es.subject = ?)";
    $params[] = $selected_subject;
    $params[] = $selected_subject;
}

if ($selected_section !== 'all') {
    $where .= " AND (es.section = ? OR sd.section = ?)";
    $params[] = $selected_section;
    $params[] = $selected_section;
}

if ($selected_period !== 'all') {
    $where .= " AND (e.academic_period = ? OR e.covered_periods LIKE ?)";
    $params[] = $selected_period;
    $params[] = "%" . $selected_period . "%";
}

if ($selected_semester !== 'all') {
    $where .= " AND (e.semester = ? OR EXISTS (SELECT 1 FROM lesson_materials lm WHERE lm.exam_id = e.id AND lm.semester = ?))";
    $params[] = $selected_semester;
    $params[] = $selected_semester;
}

if ($selected_sy !== 'all') {
    $where .= " AND (e.school_year = ? OR EXISTS (SELECT 1 FROM lesson_materials lm WHERE lm.exam_id = e.id AND lm.school_year = ?))";
    $params[] = $selected_sy;
    $params[] = $selected_sy;
}

$stmtStats = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT es.id) as total_submissions,
        SUM(CASE WHEN es.review_status = 'published' THEN 1 ELSE 0 END) as total_published,
        SUM(CASE WHEN es.review_status IN ('pending_review', 'draft') THEN 1 ELSE 0 END) as pending_review,
        SUM(CASE WHEN es.review_status = 'published' AND DATE(es.published_at) = CURRENT_DATE() THEN 1 ELSE 0 END) as published_today,
        SUM(CASE WHEN es.review_status = 'published' AND (es.status = 'Pass' OR es.percentage >= 75) THEN 1 ELSE 0 END) as total_pass,
        SUM(CASE WHEN es.review_status = 'published' AND (es.status = 'Fail' OR es.percentage < 75) THEN 1 ELSE 0 END) as total_fail,
        SUM(CASE WHEN es.review_status = 'published' AND es.qualification_status = 'qualified' THEN 1 ELSE 0 END) as total_qualified,
        SUM(CASE WHEN es.review_status = 'published' AND es.qualification_status = 'not_qualified' THEN 1 ELSE 0 END) as total_not_qualified,
        SUM(CASE WHEN es.qualification_status = 'pending' THEN 1 ELSE 0 END) as total_pending_qual,
        AVG(CASE WHEN es.review_status = 'published' THEN es.percentage ELSE NULL END) as avg_percentage,
        MAX(CASE WHEN es.review_status = 'published' THEN es.percentage ELSE NULL END) as max_percentage,
        MIN(CASE WHEN es.review_status = 'published' THEN es.percentage ELSE NULL END) as min_percentage
    FROM exam_submissions es
    LEFT JOIN exams e ON es.exam_id = e.id
    LEFT JOIN student_details sd ON es.student_id = sd.user_id
    $where
");
$stmtStats->execute($params);

$stmtList = $pdo->prepare("
    SELECT es.*, e.exam_category, e.qualifying_passing_percentage, e.qualifying_max_attempts, u.fullname as student_name, sd.section as student_section
    FROM exam_submissions es
    LEFT JOIN exams e ON es.exam_id = e.id
    LEFT JOIN users u ON es.student_id = u.id
    LEFT JOIN student_details sd ON es.student_id = sd.user_id
    $where 
    GROUP BY es.id
    ORDER BY es.id DESC LIMIT 200
");
$stmtList->execute($params);

$stats = $stmtStats->fetch(PDO::FETCH_ASSOC);
$submissions = $stmtList->fetchAll(PDO::FETCH_ASSOC);

$total_submissions = intval($stats['total_submissions'] ?? 0);
$total_published = intval($stats['total_published'] ?? 0);
$pending_review = intval($stats['pending_review'] ?? 0);
$published_today = intval($stats['published_today'] ?? 0);
$pass = intval($stats['total_pass'] ?? 0);
$fail = intval($stats['total_fail'] ?? 0);
$pass_rate = $total_published > 0 ? min(100.0, round(($pass / $total_published) * 100, 1)) : 0.0;
$fail_rate = $total_published > 0 ? min(100.0, round(($fail / $total_published) * 100, 1)) : 0.0;
$avg_percentage = floatval($stats['avg_percentage'] ?? 0.0);
$max_percentage = floatval($stats['max_percentage'] ?? 0.0);

$stmtExams = $pdo->prepare("SELECT DISTINCT exam_title FROM exam_submissions WHERE teacher_id = ?");
$stmtExams->execute([$teacher_id]);
$exam_options = $stmtExams->fetchAll(PDO::FETCH_COLUMN);

$success_msg = "";
$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_review_status'])) {
    validateCSRFToken();
    $submission_id = intval($_POST['submission_id'] ?? 0);
    $new_status = $_POST['new_review_status'] ?? '';
    $remarks = trim(sanitizeInput($_POST['teacher_remarks'] ?? ''));

    if ($submission_id > 0) {
        try {
            AuthorizationService::enforceSubmissionAccess($teacher_id, $submission_id);
            $wfRes = ResultWorkflowService::transitionStatus($submission_id, $new_status, $teacher_id, $remarks);

            $success_msg = "Submission #{$submission_id} review status updated to " . ucfirst(str_replace('_', ' ', $wfRes['new_status'])) . "!";
        } catch (Exception $e) {
            $error_msg = "Workflow Error: " . $e->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['override_item_score'])) {
    validateCSRFToken();
    $submission_id = intval($_POST['submission_id'] ?? 0);
    $question_id = intval($_POST['question_id'] ?? 0);
    $new_points = floatval($_POST['new_points'] ?? 0);
    $reason = trim(sanitizeInput($_POST['override_reason'] ?? ''));
    $new_answer = isset($_POST['new_answer']) ? trim(sanitizeInput($_POST['new_answer'])) : null;

    if ($submission_id > 0 && $question_id > 0) {
        try {
            $res = ResultWorkflowService::overrideScore($submission_id, $question_id, $new_points, $teacher_id, $reason, $new_answer);
            $success_msg = "Item #{$question_id} score overridden to {$new_points} pts! Recalculated Total: {$res['recalculated_total_score']} ({$res['recalculated_percentage']}%)";
        } catch (Exception $e) {
            $error_msg = "Item Override Error: " . $e->getMessage();
        }
    } else {
        $error_msg = "Item Override Error: Invalid submission ID or question ID provided.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rerun_ocr_ai'])) {
    validateCSRFToken();
    $submission_id = intval($_POST['submission_id'] ?? 0);
    if ($submission_id > 0) {
        try {
            $res = ResultWorkflowService::reprocessOcr($submission_id, $teacher_id, "Teacher requested OCR reprocessing via Reports interface");
            $success_msg = "Re-ran OCR evaluation using production scoring engine for submission #{$submission_id}! Recalculated Score: {$res['new_total']} / {$res['total_possible']} ({$res['percentage']}%) - {$res['status']}";
        } catch (Exception $e) {
            $error_msg = "OCR Reprocessing Error: " . $e->getMessage();
        }
    } else {
        $error_msg = "OCR Reprocessing Error: Invalid submission ID.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_publish'])) {
    validateCSRFToken();
    $sub_ids = $_POST['submission_ids'] ?? [];
    if (is_array($sub_ids) && !empty($sub_ids)) {
        $sub_ids = array_map('intval', $sub_ids);
        $res = ResultWorkflowService::bulkPublishSubmissions($sub_ids, $teacher_id, 'Bulk published by teacher');
        $success_msg = "Successfully published {$res['published_count']} submission(s)!";
        if (!empty($res['errors'])) {
            $error_msg = "Notice during bulk publish: " . implode('; ', $res['errors']);
        }
    } else {
        $error_msg = "No submissions selected for bulk publication.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['publish_entire_exam'])) {
    validateCSRFToken();
    $exam_id = intval($_POST['exam_id'] ?? 0);
    if ($exam_id > 0) {
        try {
            $res = ResultWorkflowService::publishEntireExam($exam_id, $teacher_id, 'Published entire exam by teacher');
            $success_msg = "Successfully published all {$res['published_count']} submission(s) for Exam #{$exam_id}!";
            if (!empty($res['errors'])) {
                $error_msg = "Notice during exam publication: " . implode('; ', $res['errors']);
            }
        } catch (Exception $e) {
            $error_msg = "Exam Publication Error: " . $e->getMessage();
        }
    } else {
        $error_msg = "Invalid exam ID specified for publication.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuestBank - Reports & Analytics</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Plus Jakarta Sans', sans-serif; } </style>
</head>
<body class="bg-[#fffbf7] min-h-screen flex">
    <?php require_once __DIR__ . '/../includes/teacher_sidebar.php'; ?>
    <main class="flex-1 ml-16 lg:ml-64 p-6 md:p-12 overflow-y-auto min-h-screen">
        <div class="max-w-6xl mx-auto space-y-6">
        
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <a href="dashboard.php" class="text-xs font-bold text-orange-600 hover:underline"><i class="fa-solid fa-arrow-left mr-1"></i> Back to Dashboard</a>
                <h1 class="text-2xl font-extrabold text-stone-800 mt-2"><i class="fa-solid fa-chart-pie text-orange-600 mr-1"></i> Class Performance & Analytics</h1>
                <p class="text-xs text-stone-400">Statistical breakdown of OCR scanned papers and student scores.</p>
            </div>

            <form method="GET" action="reports.php" class="flex items-center gap-2 flex-wrap">
                <select name="exam_title" onchange="this.form.submit()" class="bg-white border border-stone-200 text-xs font-bold rounded-xl px-3 py-2 outline-none cursor-pointer focus:border-orange-500 shadow-sm">
                    <option value="all" <?php echo $selected_exam === 'all' ? 'selected' : ''; ?>>All Evaluated Exams</option>
                    <?php foreach ($exam_options as $ex): ?>
                        <option value="<?php echo htmlspecialchars($ex); ?>" <?php echo $selected_exam === $ex ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($ex); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="exam_category" onchange="this.form.submit()" class="bg-white border border-stone-200 text-xs font-bold rounded-xl px-3 py-2 outline-none cursor-pointer focus:border-orange-500 shadow-sm">
                    <option value="all" <?php echo $selected_category === 'all' ? 'selected' : ''; ?>>All Categories</option>
                    <option value="regular" <?php echo $selected_category === 'regular' ? 'selected' : ''; ?>>Regular Exams</option>
                    <option value="qualifying" <?php echo $selected_category === 'qualifying' ? 'selected' : ''; ?>>Qualifying Exams</option>
                </select>

                <select name="qualification_status" onchange="this.form.submit()" class="bg-white border border-stone-200 text-xs font-bold rounded-xl px-3 py-2 outline-none cursor-pointer focus:border-orange-500 shadow-sm">
                    <option value="all" <?php echo $selected_qual_status === 'all' ? 'selected' : ''; ?>>All Qual Results</option>
                    <option value="qualified" <?php echo $selected_qual_status === 'qualified' ? 'selected' : ''; ?>>Qualified Only</option>
                    <option value="not_qualified" <?php echo $selected_qual_status === 'not_qualified' ? 'selected' : ''; ?>>Not Qualified Only</option>
                    <option value="pending" <?php echo $selected_qual_status === 'pending' ? 'selected' : ''; ?>>Pending Qualification</option>
                </select>
            </form>
        </div>

        <?php if (!empty($success_msg)): ?>
            <div id="flash_success" class="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_msg)): ?>
            <div id="flash_error" class="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <i class="fa-solid fa-circle-xmark"></i> <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <div class="bg-white p-4 border border-stone-200 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-stone-400">Total Scanned</p>
                <p class="text-2xl font-black text-stone-800 mt-1"><?php echo $total_students; ?></p>
            </div>
            <div class="bg-emerald-50 p-4 border border-emerald-100 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-emerald-700">Passed</p>
                <p class="text-2xl font-black text-emerald-800 mt-1"><?php echo $pass; ?></p>
            </div>
            <div class="bg-rose-50 p-4 border border-rose-100 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-rose-700">Failed</p>
                <p class="text-2xl font-black text-rose-800 mt-1"><?php echo $fail; ?></p>
            </div>
            <div class="bg-orange-50 p-4 border border-orange-100 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-orange-700">Pass Rate</p>
                <p class="text-2xl font-black text-orange-800 mt-1"><?php echo number_format($pass_rate, 1); ?>%</p>
            </div>
            <div class="bg-white p-4 border border-stone-200 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-stone-400">Class Average</p>
                <p class="text-2xl font-black text-stone-800 mt-1"><?php echo number_format($avg_percentage, 1); ?>%</p>
            </div>
            <div class="bg-white p-4 border border-stone-200 rounded-2xl shadow-sm text-center">
                <p class="text-[10px] font-bold uppercase text-stone-400">Highest Score</p>
                <p class="text-2xl font-black text-emerald-600 mt-1"><?php echo number_format($max_percentage, 1); ?>%</p>
            </div>
        </div>

        <div class="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div class="flex items-center justify-between border-b pb-3">
                <h3 class="text-sm font-bold uppercase tracking-wider text-stone-700">
                    <i class="fa-solid fa-list text-orange-500 mr-1"></i> Student Grade Submissions Master List
                </h3>
                <a href="export_report_pdf.php?exam_title=<?php echo urlencode($selected_exam); ?>" target="_blank" class="bg-stone-900 hover:bg-orange-600 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-sm flex items-center gap-1.5">
                    <i class="fa-solid fa-file-pdf text-rose-400"></i> Export Analytics PDF Report
                </a>
            </div>

            <?php if (!empty($submissions)): ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs border-collapse">
                        <thead>
                            <tr class="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase font-bold text-[10px]">
                                <th class="p-3">Student Name</th>
                                <th class="p-3">Exam Title</th>
                                <th class="p-3">Category & Qualification</th>
                                <th class="p-3">Format</th>
                                <th class="p-3 text-center">Score (Correct / Total)</th>
                                <th class="p-3 text-center">Percentage</th>
                                <th class="p-3 text-center">Grading Status</th>
                                <th class="p-3 text-center">Review Workflow</th>
                                <th class="p-3 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-stone-100 font-medium text-stone-700">
                            <?php foreach ($submissions as $sub): ?>
                                <?php 
                                    $rStatus = $sub['review_status'] ?? 'published';
                                    $rBadgeClass = 'bg-stone-100 text-stone-700';
                                    if ($rStatus === 'published') $rBadgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-200';
                                    elseif ($rStatus === 'reviewed') $rBadgeClass = 'bg-blue-100 text-blue-800 border-blue-200';
                                    elseif ($rStatus === 'pending_review') $rBadgeClass = 'bg-amber-100 text-amber-800 border-amber-200';
                                    elseif ($rStatus === 'draft') $rBadgeClass = 'bg-stone-100 text-stone-600 border-stone-200';
                                    elseif ($rStatus === 'archived') $rBadgeClass = 'bg-stone-200 text-stone-500 border-stone-300';
                                ?>
                                <tr class="hover:bg-stone-50/50 transition-all">
                                    <td class="p-3 font-bold text-stone-800"><?php echo htmlspecialchars($sub['student_name']); ?></td>
                                    <td class="p-3"><?php echo htmlspecialchars($sub['exam_title']); ?></td>
                                    <td class="p-3">
                                        <?php if (($sub['exam_category'] ?? 'regular') === 'qualifying'): ?>
                                            <span class="bg-orange-100 text-orange-800 text-[10px] font-black px-2 py-0.5 rounded uppercase">Qualifying</span>
                                            <?php if (($sub['qualification_status'] ?? '') === 'qualified'): ?>
                                                <span class="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[10px] ml-1">Qualified</span>
                                            <?php elseif (($sub['qualification_status'] ?? '') === 'not_qualified'): ?>
                                                <span class="bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded text-[10px] ml-1">Not Qualified</span>
                                            <?php else: ?>
                                                <span class="bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded text-[10px] ml-1">Pending</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="bg-stone-100 text-stone-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Regular</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <span class="bg-stone-100 text-stone-600 font-bold px-2 py-0.5 rounded text-[10px] uppercase">
                                            <?php echo htmlspecialchars($sub['upload_type']); ?>
                                        </span>
                                    </td>
                                    <td class="p-3 text-center font-mono font-bold">
                                        <?php echo $sub['correct_count'] . ' / ' . $sub['total_items']; ?>
                                    </td>
                                    <td class="p-3 text-center font-bold text-stone-800">
                                        <?php echo number_format($sub['percentage'], 1); ?>%
                                    </td>
                                    <td class="p-3 text-center">
                                        <span class="px-2.5 py-1 rounded-md text-[10px] font-bold <?php echo ($sub['status'] === 'Pass') ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'; ?>">
                                            <?php echo htmlspecialchars($sub['status']); ?>
                                        </span>
                                    </td>
                                    <td class="p-3 text-center">
                                        <span class="px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase border <?php echo $rBadgeClass; ?>">
                                            <i class="fa-solid fa-circle text-[7px] mr-1"></i><?php echo ucfirst(str_replace('_', ' ', $rStatus)); ?>
                                        </span>
                                    </td>
                                    <td class="p-3 text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <?php if ($rStatus !== 'published'): ?>
                                                <form method="POST" action="reports.php" class="inline">
                                                    <?php echo csrfInputField(); ?>
                                                    <input type="hidden" name="submission_id" value="<?php echo $sub['id']; ?>">
                                                    <input type="hidden" name="new_review_status" value="published">
                                                    <button type="submit" name="update_review_status" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-2.5 py-1 rounded-lg transition-all shadow-sm">
                                                        <i class="fa-solid fa-paper-plane mr-0.5"></i> Publish
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <?php if ($rStatus === 'pending_review'): ?>
                                                <form method="POST" action="reports.php" class="inline">
                                                    <?php echo csrfInputField(); ?>
                                                    <input type="hidden" name="submission_id" value="<?php echo $sub['id']; ?>">
                                                    <input type="hidden" name="new_review_status" value="reviewed">
                                                    <button type="submit" name="update_review_status" class="bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] px-2.5 py-1 rounded-lg transition-all shadow-sm">
                                                        <i class="fa-solid fa-check mr-0.5"></i> Approve
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <button type="button" onclick="openReviewModal(<?php echo htmlspecialchars(json_encode($sub)); ?>)" class="bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-[10px] px-2.5 py-1 rounded-lg transition-all border border-stone-200">
                                                <i class="fa-solid fa-sliders"></i> Review
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-12 text-stone-400">
                    <i class="fa-solid fa-chart-line text-4xl mb-3 text-stone-300"></i>
                    <p class="text-sm font-bold">No evaluation reports found</p>
                    <p class="text-xs mt-1">Suriin ang mga exam sheets gamit ang OCR Answer Checker para lumabas dito ang analytics.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>

    
    <div id="review_modal" data-testid="review-submission-modal" class="fixed inset-0 bg-stone-950/80 backdrop-blur-sm hidden items-center justify-center z-50 p-4 animate-fadeIn">
        <div class="bg-white rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4 border border-stone-200 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div class="flex items-center justify-between border-b border-stone-100 pb-3">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-sm">
                        <i class="fa-solid fa-list-check"></i>
                    </div>
                    <div>
                        <h4 class="font-extrabold text-sm text-stone-800" id="modal_title">Review Exam Submission</h4>
                        <p class="text-[10px] text-stone-400 font-medium" id="modal_subtitle">Inspect OCR output, AI confidence, and update workflow status.</p>
                    </div>
                </div>
                <button type="button" onclick="closeReviewModal()" class="text-stone-400 hover:text-stone-700 text-sm p-1">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            
            <form method="POST" action="reports.php" class="space-y-4">
                <?php echo csrfInputField(); ?>
                <input type="hidden" name="submission_id" id="modal_submission_id">

                <div class="grid grid-cols-2 gap-3 text-xs">
                    <div class="bg-stone-50 p-3 rounded-xl border border-stone-200">
                        <span class="text-[10px] font-bold uppercase text-stone-400">OCR Extracted Text</span>
                        <div class="mt-1 font-mono text-[11px] text-stone-700 bg-white p-2 rounded border max-h-24 overflow-y-auto whitespace-pre-wrap" id="modal_ocr_text"></div>
                    </div>
                    <div class="bg-stone-50 p-3 rounded-xl border border-stone-200">
                        <span class="text-[10px] font-bold uppercase text-stone-400">OCR Confidence Rating</span>
                        <p class="mt-1 font-extrabold text-stone-800 text-sm" id="modal_ocr_confidence"></p>
                    </div>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-stone-700">Teacher Remarks / Grade Notes</label>
                    <textarea name="teacher_remarks" id="modal_teacher_remarks" rows="2" placeholder="Add feedback remarks for the student..." class="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-xs outline-none focus:border-orange-500 resize-none font-medium text-stone-800"></textarea>
                </div>

                <div class="space-y-1">
                    <label class="text-xs font-bold text-stone-700">Update Review Workflow State</label>
                    <select name="new_review_status" id="modal_review_status" class="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-800 outline-none focus:border-orange-500">
                        <option value="pending_review">Pending Review</option>
                        <option value="reviewed">Reviewed (Approved)</option>
                        <option value="finalized">Finalized</option>
                        <option value="published">Published (Visible to Student)</option>
                        <option value="archived">Archived</option>
                    </select>
                </div>

                <div class="pt-3 border-t border-stone-100 flex items-center justify-between">
                    <button type="submit" name="rerun_ocr_ai" onclick="return confirm('Re-run AI comparative grading on this submission?');" class="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-sm transition-all flex items-center gap-1.5">
                        <i class="fa-solid fa-rotate"></i> Re-run AI Check
                    </button>
                    <button type="submit" name="update_review_status" data-testid="review-status-submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-6 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-2">
                        <i class="fa-solid fa-floppy-disk"></i> Save Review Changes
                    </button>
                </div>
            </form>

            
            <div class="pt-4 border-t border-stone-200 space-y-3">
                <h5 class="text-xs font-extrabold text-stone-800 flex items-center gap-1.5">
                    <i class="fa-solid fa-pen-to-square text-orange-600"></i> Item-Level Score Override (Audit-Logged)
                </h5>
                <form method="POST" action="reports.php" data-testid="item-override-form" class="bg-stone-50 p-3 rounded-xl border border-stone-200 space-y-3 text-xs">
                    <?php echo csrfInputField(); ?>
                    <input type="hidden" name="submission_id" id="override_modal_submission_id" value="102">
                    <div class="grid grid-cols-3 gap-2">
                        <div>
                            <label class="block text-[10px] font-bold text-stone-600">Question ID</label>
                            <input type="number" name="question_id" required placeholder="e.g. 1" data-testid="item-question-id" class="w-full bg-white border border-stone-200 rounded-lg px-2.5 py-1.5 font-bold text-stone-800">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold text-stone-600">New Points</label>
                            <input type="number" step="0.5" name="new_points" required placeholder="1.0" data-testid="item-points-input" class="w-full bg-white border border-stone-200 rounded-lg px-2.5 py-1.5 font-bold text-stone-800">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold text-stone-600">Student Answer (Optional)</label>
                            <input type="text" name="new_answer" placeholder="e.g. a" class="w-full bg-white border border-stone-200 rounded-lg px-2.5 py-1.5 text-stone-800">
                        </div>
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-stone-600">Mandatory Override Reason</label>
                        <input type="text" name="override_reason" required placeholder="Reason for grade correction..." data-testid="item-reason-input" class="w-full bg-white border border-stone-200 rounded-lg px-2.5 py-1.5 text-stone-800 font-medium">
                    </div>
                    <div class="text-right">
                        <button type="submit" name="override_item_score" data-testid="item-override-submit" class="bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-sm">
                            <i class="fa-solid fa-gavel mr-1"></i> Override Item Score
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <script>
        function openReviewModal(sub) {
            document.getElementById('modal_submission_id').value = sub.id;
            document.getElementById('override_modal_submission_id').value = sub.id;
            document.getElementById('modal_title').innerText = "Review Submission #" + sub.id + " (" + sub.student_name + ")";
            document.getElementById('modal_subtitle').innerText = "Exam: " + sub.exam_title + " | Score: " + sub.correct_count + "/" + sub.total_items;
            document.getElementById('modal_ocr_text').innerText = sub.ocr_text || "No raw OCR text recorded";
            document.getElementById('modal_ocr_confidence').innerText = (sub.ocr_confidence || 85.0) + "%";
            document.getElementById('modal_teacher_remarks').value = sub.teacher_remarks || '';
            document.getElementById('modal_review_status').value = sub.review_status || 'pending_review';

            document.getElementById('review_modal').classList.remove('hidden');
            document.getElementById('review_modal').classList.add('flex');
        }

        function closeReviewModal() {
            document.getElementById('review_modal').classList.add('hidden');
            document.getElementById('review_modal').classList.remove('flex');
        }
    </script>
</body>
</html>